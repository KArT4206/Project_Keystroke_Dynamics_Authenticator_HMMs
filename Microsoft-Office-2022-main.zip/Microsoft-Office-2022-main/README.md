# Microsoft-Office-2022

Steps to Download and Install latest Microsoft Office 2022 in Windows.

1. Download the zip file from the link https://github.com/singhalmridul/Microsoft-Office-2022

![image](https://user-images.githubusercontent.com/79533228/169352582-4c57f204-0e2f-47a1-b497-02b8dfad844c.png)

2. Now open the File Explorer > Downloads

![image](https://user-images.githubusercontent.com/79533228/169352921-aee557aa-073e-44dd-a696-37acac68d87f.png)

3. Extract the zip file.

![image](https://user-images.githubusercontent.com/79533228/169353074-acfca6c5-6a7e-47bc-9cda-4e0261603bf6.png)

![image](https://user-images.githubusercontent.com/79533228/169353174-4e754f95-659b-48c3-92f7-8f78a6bca584.png)

![image](https://user-images.githubusercontent.com/79533228/169353196-e7f134d2-e9b7-4f44-88ec-6f27786b4051.png)

4. Run "Setup64.exe" to install the Microsoft Office 2022.

![image](https://user-images.githubusercontent.com/79533228/169353432-320bf5c9-8b41-441d-8b6f-625a04073e0d.png)

![image](https://user-images.githubusercontent.com/79533228/169353475-ea0f5b43-3fa7-4a91-98de-c61d71997a18.png)

![image](https://user-images.githubusercontent.com/79533228/169353496-c58a8497-df29-4edd-bbbf-e5e764625bb6.png)

5. Installation of Microsoft Office 2022 complete

![image](https://user-images.githubusercontent.com/79533228/169353769-a032c721-953a-44fd-a369-c2a74d09795b.png)

6. Now go inside the File Explorer > Downloads > Microsoft-Office-2022-main (extracted folder) > Crack

![image](https://user-images.githubusercontent.com/79533228/169354000-3a64fdc0-ea96-4bc3-a6ae-08a1eac5385e.png)

7. Right click and Run the file as administrator as shown in the picture.

![image](https://user-images.githubusercontent.com/79533228/169354128-63902368-b6b0-4423-ba93-6407120c591d.png)

8. Following terminal will open up, select the preffered option (Select option 2)

![image](https://user-images.githubusercontent.com/79533228/169354393-5a57c230-f99c-45a3-a4c2-ffec1c9c8586.png)

![image](https://user-images.githubusercontent.com/79533228/169354432-b1cbd09d-555c-4365-8829-8d56f2ea15be.png)

![image](https://user-images.githubusercontent.com/79533228/169354489-c0cdcdef-0b96-47ca-ad2e-ec440c73dbe1.png)

9. Finally the crack is succesfully installed. 

![image](https://user-images.githubusercontent.com/79533228/169354555-81b3adeb-f61e-4f56-a90c-213bef826185.png)

10. Open Word or any other office product and check whether office is activated or not.

![image](https://user-images.githubusercontent.com/79533228/169354799-cdd18017-72a4-42af-85f7-4a3c3c4cfd03.png)

**Congratulations !! you have succesfully installed and cracked Microsoft Office 2022 on your Windows Operating System.

For the Step by Step installation video guide, checkout https://youtu.be/aNF7fP6Wt5A
